<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMerchantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('merchants', function (Blueprint $table) {
            $table->bigIncrements('merchant_id');
            $table->string('title');
            $table->bigInteger('mc_id');
            $table->bigInteger('g_id');
            $table->bigInteger('msp_id');
            $table->bigInteger('merchant_cor_id');
            $table->string('portal_username');
            $table->string('portal_password');
            $table->string('currency');
            $table->string('description');
            $table->string('api_username');
            $table->string('api_password')->nullable();
            $table->string('api_tanskey')->nullable();
            $table->string('type');
            $table->string('allow_refund')->nullable();
            $table->string('account_number')->nullable();
            $table->string('gateway_version')->nullable();
            $table->string('bank_name')->nullable();
            $table->string('bank_website')->nullable();
            $table->string('product_name')->nullable();
            $table->string('process_limit')->nullable();
            $table->string('sales_limit')->nullable();
            $table->string('decline_count')->nullable();
            $table->string('processed_amount')->nullable();
            $table->string('reserved_amount')->nullable();
            $table->string('fee_per_transaction')->nullable();
            $table->string('merchant_reserved_amount')->nullable();
            $table->string('discount_fee')->nullable();
            $table->string('chargeback_fee')->nullable();
            $table->string('alert_fee')->nullable();
            $table->string('contact_phone')->nullable();
            $table->string('contact_email')->nullable();
            $table->string('support_fix')->nullable();
            $table->string('trial_days')->nullable();
            $table->string('gateway_custom1')->nullable();
            $table->string('gateway_custom2')->nullable();
            $table->string('is_tokenized')->nullable();
            $table->string('is_testmode')->nullable();
            $table->string('is_handling_allowed')->nullable();
            $table->string('status_account')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('merchants');
    }
}
