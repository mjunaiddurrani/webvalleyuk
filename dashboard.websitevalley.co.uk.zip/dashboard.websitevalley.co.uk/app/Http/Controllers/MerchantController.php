<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Merchant;
use App\MerchantCategory;
use App\Gateway;
use App\MSP;
use App\MerchantCorporation;
use DB;
class MerchantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $merchants=Merchant::all();
        return view('merchants.index',compact('merchants'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $msp=MSP::where('status',1)->get();
        $gateway=Gateway::where('status',1)->get();
        $merchantCategory=MerchantCategory::where('status',1)->get();
        $merchantCorporation=MerchantCorporation::where('status',1)->get();
        return view('merchants.create',compact('msp','gateway','merchantCategory','merchantCorporation'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(isset($request->allow_refund)){
            $refund = 1;
        }
        elseif(!isset($request->allow_refund)){
            $refund = 0;
        }
        if(isset($request->is_tokenized)){
            $is_tokenized = 1;
        }
        elseif(!isset($request->is_tokenized)){
            $is_tokenized = 0;
        }
        if(isset($request->is_testmode)){
            $is_testmode = 1;
        }
        elseif(!isset($request->is_testmode)){
            $is_testmode = 0;
        }
        if(isset($request->is_handling_allowed)){
            $is_handling_allowed = 1;
        }
        elseif(!isset($request->is_handling_allowed)){
            $is_handling_allowed = 0;
        }
        // dd($refund);
        Merchant::create([
            'title'=>$request->title,
            'mc_id'=>$request->mc_id,
            'g_id'=>$request->g_id,
            'msp_id'=>$request->msp_id,
            'merchant_cor_id'=>$request->merchantcor_id,
            'portal_username'=>$request->portal_username,
            'portal_password'=>$request->portal_password,
            'currency'=>$request->currency,
            'description'=>$request->description,
            'api_username'=>$request->api_username,
            'api_password'=>$request->api_password,
            'api_tanskey'=>$request->api_tanskey,
            'type'=>$request->type,
            'allow_refund'=>$refund,
            'account_number'=>$request->account_number,
            'gateway_version'=>$request->gateway_version,
            'bank_name'=>$request->bank_name,
            'bank_website'=>$request->bank_website,
            'product_name'=>$request->product_name,
            'process_limit'=>$request->process_limit,
            'sales_limit'=>$request->sales_limit,
            'decline_count'=>$request->decline_count,
            'processed_amount'=>$request->processed_amount,
            'reserved_amount'=>$request->reserved_amount,
            'fee_per_transaction'=>$request->fee_per_transaction,
            'merchant_reserved_amount'=>$request->merchant_reserved_amount,
            'discount_fee'=>$request->discount_fee,
            'chargeback_fee'=>$request->chargeback_fee,
            'alert_fee'=>$request->alert_fee,
            'contact_phone'=>$request->contact_phone,
            'contact_email'=>$request->contact_email,
            'support_fix'=>$request->support_fix,
            'trial_days'=>$request->trial_days,
            'gateway_custom1'=>$request->gateway_custom1,
            'gateway_custom2'=>$request->gateway_custom2,
            'is_tokenized'=>$is_tokenized,
            'is_testmode'=>$is_testmode,
            'is_handling_allowed'=>$is_handling_allowed,
            'status_account'=>$request->status_account
        ]);
        toastr()->success('Merchant added successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $merchantdat=Merchant::find($id);
        return view('merchants.show',compact('merchantdat'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $merchantdat=Merchant::find($id);
        // dd($merchantdat);
        return view('merchants.edit',compact('merchantdat'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(isset($request->allow_refund)){
            $refund = 1;
        }
        elseif(!isset($request->allow_refund)){
            $refund = 0;
        }
        if(isset($request->is_tokenized)){
            $is_tokenized = 1;
        }
        elseif(!isset($request->is_tokenized)){
            $is_tokenized = 0;
        }
        if(isset($request->is_testmode)){
            $is_testmode = 1;
        }
        elseif(!isset($request->is_testmode)){
            $is_testmode = 0;
        }
        if(isset($request->is_handling_allowed)){
            $is_handling_allowed = 1;
        }
        elseif(!isset($request->is_handling_allowed)){
            $is_handling_allowed = 0;
        }

        $updatemerchant = Merchant::where('merchant_id',$id)->update([
            'title'=>$request->title,
            'mc_id'=>$request->mc_id,
            'g_id'=>$request->g_id,
            'msp_id'=>$request->msp_id,
            'merchant_cor_id'=>$request->merchantcor_id,
            'portal_username'=>$request->portal_username,
            'portal_password'=>$request->portal_password,
            'currency'=>$request->currency,
            'description'=>$request->description,
            'api_username'=>$request->api_username,
            'api_password'=>$request->api_password,
            'api_tanskey'=>$request->api_tanskey,
            'type'=>$request->type,
            'allow_refund'=>$refund,
            'account_number'=>$request->account_number,
            'gateway_version'=>$request->gateway_version,
            'bank_name'=>$request->bank_name,
            'bank_website'=>$request->bank_website,
            'product_name'=>$request->product_name,
            'process_limit'=>$request->process_limit,
            'sales_limit'=>$request->sales_limit,
            'decline_count'=>$request->decline_count,
            'processed_amount'=>$request->processed_amount,
            'reserved_amount'=>$request->reserved_amount,
            'fee_per_transaction'=>$request->fee_per_transaction,
            'merchant_reserved_amount'=>$request->merchant_reserved_amount,
            'discount_fee'=>$request->discount_fee,
            'chargeback_fee'=>$request->chargeback_fee,
            'alert_fee'=>$request->alert_fee,
            'contact_phone'=>$request->contact_phone,
            'contact_email'=>$request->contact_email,
            'support_fix'=>$request->support_fix,
            'trial_days'=>$request->trial_days,
            'gateway_custom1'=>$request->gateway_custom1,
            'gateway_custom2'=>$request->gateway_custom2,
            'is_tokenized'=>$is_tokenized,
            'is_testmode'=>$is_testmode,
            'is_handling_allowed'=>$is_handling_allowed,
            'status_account'=>$request->status_account
        ]);
        return redirect()->route('merchant.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Merchant::destroy($id);
        return redirect()->route('merchant.index');
    }
}
