<?php

namespace App\Http\Controllers;

use App\Currency;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Leads;



class LeadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $leads = Leads::orderBy('id','desc')->get();
    //    $leads=DB::table('payments')
    //    ->join('leads','leads.id','payments.user_id')
    //    ->get();
    //    dd($leads);
        return view('leads.index',compact('leads'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $currency=Currency::all();
       return view('leads.create',compact('currency'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $urlarray = []; 
        for ($i=0; $i < count($request->amount) ; $i++) { 
            if($request->package_amount[$i] == 'other'){
               $discountedamount = $request->amount[$i] - $request->discount_amount[$i];
            }
            else{
                $discountedamount = $request->amount[$i];
            }
            $leads = Leads::create([
                'fname' => $request->fname,
                'lname' => $request->lname,
                'email' => $request->email,
                'address' => $request->address,
                'phonenumber' => $request->phonenumber,
                'zipcode' => $request->zipcode,
                'amount' => $discountedamount,
                'description' => $request->description[$i],
                'package_amount' => $request->package_amount[$i],
                'discount_amount' => $request->discount_amount[$i],
                'user_id' => Auth::user()->id,
                'currency' => $request->currency,
                'brand' => $request->brand
                ]);
            // $makeurl = Leads::where('fname',$request->fname)->where('phonenumber',$request->phonenumber)->first();
            $urlencode = time().rand(10,1000);
            if($request->brand=="https://www.logospots.com/")
            {
                $url = $request->brand."stripe?TOKEN=$urlencode";
            }
            else
            {
                $url = $request->brand."securitypayment.php?TOKEN=$urlencode";
            }
            $updateurl = Leads::where('id' , $leads->id)->update([
                'url' => $url,
                'token' => $urlencode
            ]);
            $urlarray[] = array("url"=>$url);
            $this->unpaidinvoice($leads->id);      
        }

        // dd($urlarray[0]['url']);
        // return view('leads.create',compact('urlarray'));
        toastr()->success('Invoice generated Successfully');
        return redirect()->route('leads.index');
    }

    public function unpaidinvoice($id){

        $unpaidinvoice = Leads::find($id);
        $data = array(
            'fname' => $unpaidinvoice->fname,
            'lname' => $unpaidinvoice->lname,
            'phonenumber' => $unpaidinvoice->phonenumber,
            'address' => $unpaidinvoice->address,
            'id' => $unpaidinvoice->id,
            'description' => $unpaidinvoice->description,
            'amount' => $unpaidinvoice->amount,
            'discount_amount' => $unpaidinvoice->discount_amount,
            'package_amount' => $unpaidinvoice->package_amount,
            'brand' => $unpaidinvoice->brand,
            'currency' => $unpaidinvoice->currency,
            'url'       => $unpaidinvoice->url
        );


        $brandUrl = $unpaidinvoice->brand;
        $parse = parse_url($brandUrl);
        $host = $parse['host'];
        $host = str_ireplace('www.', '', $host);
        
        $tos = [
            $unpaidinvoice->email,
            'payments@'.$host,
        ];

        parent::mailFun('email.invoice',$data,"mail.".$host,"payments@".$host,env('PASSWORDEMAIL'),$tos,"Please Pay Your Invoice");
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Leads::destroy($id);
        toastr()->error('Record Deleted Successfully');
        return redirect()->back();
    }

    
}
