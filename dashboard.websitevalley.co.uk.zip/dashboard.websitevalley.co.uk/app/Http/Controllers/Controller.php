<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function mailFun($viewName,$data,$mailHost,$mailUsername,$mailPassword,$tos,$subject){

            $mail = new PHPMailer(true); // notice the \  you have to use root namespace here
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                    )
                );
                $meessgeHtml = view($viewName,compact('data'))->render();
                $domainName = explode('.',$mailHost);
                $domainName = $domainName[1];
                // dd($domainName);
                // $mail->isSMTP(); // tell to use smtp
                $mail->SMTPDebug = 1;
                $mail->CharSet = "utf-8"; // set charset to utf8
                $mail->SMTPAuth = true;  // use smpt auth
                $mail->SMTPSecure = "ssl"; // or ssl
                $mail->Host = $mailHost;
                $mail->Port = 465; // most likely something different for you. This is the mailtrap.io port i use for testing. 
                $mail->Username = $mailUsername;
                $mail->IsHTML(true);
                $mail->Password = $mailPassword;
                $mail->setFrom($mailUsername, $domainName);
                $mail->Subject = $subject;
                $mail->MsgHTML($meessgeHtml);
                foreach($tos as $to){
                    $mail->addAddress($to, "payments ");
                }
                if(!$mail->send()) {
                    return false;
                } 
                else {
                    return true;
                }

            return true;
        
    }
}
