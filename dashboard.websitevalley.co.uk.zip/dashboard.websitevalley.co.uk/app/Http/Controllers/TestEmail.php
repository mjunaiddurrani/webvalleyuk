<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// require($_SERVER['DOCUMENT_ROOT']."/vendor/phpmailer/phpmailer/src/PHPMailer.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// require("/PHPMailer-master/src/PHPMailer.php");
//     require("/PHPMailer-master/src/SMTP.php");
//     require("/PHPMailer-master/src/Exception.php");


class TestEmail extends Controller
{
    //
    public function index(){
        
        // $html = view('email.invoice', compact('data'))->render();
        // dd($html);
        $mail = new PHPMailer(true); // notice the \  you have to use root namespace here
        try {
            $mail->SMTPOptions = array(
                'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
                )
                );
            $mail->isSMTP(); // tell to use smtp
            $mail->CharSet = "utf-8"; // set charset to utf8
            $mail->SMTPAuth = true;  // use smpt auth
            $mail->SMTPSecure = "tls"; // or ssl
            $mail->Host = "mail.logovalley.co.uk";
            $mail->Port = 25; // most likely something different for you. This is the mailtrap.io port i use for testing. 
            $mail->Username = "payments@logovalley.co.uk";
            $mail->IsHTML(true);
            $mail->Password = "payments@logovalley";
            $mail->setFrom("payments@logovalley.co.uk", "Logovalley Payment system");
            $mail->Subject = "Test";
            $mail->MsgHTML("this is the email from new email test");
            $mail->addAddress("payments@logovalley.co.uk", "payments ");
            $mail->addAddress("akash@inoviotech.com", "akash");
            $mail->send();
        } catch (phpmailerException $e) {
            dd($e);
        } catch (Exception $e) {
            dd($e);
        }
        die('success');
    }
}
