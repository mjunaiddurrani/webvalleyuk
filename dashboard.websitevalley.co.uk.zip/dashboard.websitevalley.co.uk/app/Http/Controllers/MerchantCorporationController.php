<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\MerchantCorporation;

class MerchantCorporationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // dd('asd');
        $merchantcor = MerchantCorporation::all();
        // dd($merchantcor);
        return view('merchant_corporation.index',compact('merchantcor'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('merchant_corporation.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        MerchantCorporation::create(['merchantcor_name'=>$request->merchantcor_name]);
        toastr()->success('Corporation added Successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(request()->ajax()){
            // dd($id);
            $data = MerchantCorporation::find($id);
            // sdd($data);
            return $data;
        }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd($request->all());
        MerchantCorporation::where('merchantcor_id' , $id)->update([
            'merchantcor_name' => $request->merchantcor_name
        ]);
        toastr()->success('Record Updated');
        return response()->json(['message'=>'success']);
    }

    public function updateStatus($status,$merchantcor_id)
    {
        if(request()->ajax())
        {
            MerchantCorporation::where('merchantcor_id' , $merchantcor_id)->update([
                'status' => $status
            ]);

            return true;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        MerchantCorporation::find($id)->delete();
        return $this->index();
    }
}
