<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\ErrorLog;

class ErrorLogController extends Controller
{
    public function store(Request $request)
    {
        $error=ErrorLog::create([
            'code'=>$request->code,
            'message'=>$request->message,
            'user_id'=>$request->user_id,
        ]);

        return $error;
    }
}
