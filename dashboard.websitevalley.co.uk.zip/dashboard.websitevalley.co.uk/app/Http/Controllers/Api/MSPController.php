<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\MSP;

class MSPController extends Controller
{
    public function index()
    {
        $msp=MSP::all();
        return $msp;
    }

    public function store(Request $request)
    {
        return MSP::create($request->all());
    }

    public function show($id)
    {
        $msp=MSP::find($id);

        return $msp;
    }
    
    public function update(Request $request,$id)
    {
        $msp=MSP::find($id);
        $msp->msp_name=$request->msp_name;
        $msp->save();
        
        return response()->json(['message'=>'updated']);
    }
    
    public function destroy($id)
    {
        MSP::destroy($id);
        return response()->json(['message'=>'deleted']);
    }
    
    public function updateStatus($status,$msp_id)
    {
        MSP::where('msp_id' , $msp_id)->update([
            'status' => $status
        ]);
            
        return response()->json(['message'=>'status updated']);
    }
}
