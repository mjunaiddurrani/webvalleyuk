<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Quote;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class QuoteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $qoute=Quote::create([
            'name'=>$request->name,
            'company'=>$request->company,
            'email'=>$request->email,
            'phone'=>$request->phone,
            'subject'=>$request->subject,
            'amount'=>$request->amount
        ]);

        $message = "<html><body>";
        $message .= "<h1>Request to start</h1>";

        $message .= "<table width='100%' border='1'> 
        <tbody>
        <tr><td colspan='5' align='center' style='font-size: 25px;font-weight: 800;'>User Details</td></tr>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>brief</th>
            <th>News subscription</th>
        </tr>
        <tr>
            <td>".$request->name."</td>
            <td>".$request->email."</td>
            <td>".$request->phone."</td>
            <td>".$request->subject."</td>
            <td>".$request->amount."</td>
        </tr>
        </tbody>
        </table>";


        $message .= "</body></html>";

        $this->sendMail("Request to start work together",$message,$request->brand);
        // $customers = DB::table('customers')->orderBy('id','desc')->get();
        return response()->json(['message','Thank you for your response we will contact you as soon as possible.']);
    }

    public function sendMail($subject,$message,$brand){

        if($brand=="logospots")
        {

            $to = 'query@logospots.com';
    
            $headers = "From: " . strip_tags('query@logospots.com') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@logospots.com') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
        elseif($brand=="wiki-pros")
        {
            
            $to = 'query@wiki-pros.com';
    
            $headers = "From: " . strip_tags('query@wiki-pros.com') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@wiki-pros.com') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
        elseif($brand=="ghostwriting")
        {

            $to = 'query@ghostwritingfounder.com';
    
            $headers = "From: " . strip_tags('query@ghostwritingfounder.com') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@ghostwritingfounder.com') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
        elseif($brand=="astorsdigital")
        {

            $to = 'query@astorsdigital.com';
    
            $headers = "From: " . strip_tags('query@astorsdigital.com') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@astorsdigital.com') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
        elseif($brand=="thewebfounders")
        {

            $to = 'query@thewebfounders.com';
    
            $headers = "From: " . strip_tags('query@thewebfounders.com') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@thewebfounders.com') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
        
        elseif($brand=="Get your Logo")
        {

            $to = 'query@getyourlogo.co.uk';
    
            $headers = "From: " . strip_tags('query@getyourlogo.co.uk') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@getyourlogo.co.uk') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
        
        elseif($brand=="logovalley")
        {

            $to = 'query@logovalley.co.uk';
    
            $headers = "From: " . strip_tags('query@logovalley.co.uk') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@logovalley.co.uk') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
        
        elseif($brand=="webvalleyuk")
        {

            $to = 'query@websitevalley.co.uk';
    
            $headers = "From: " . strip_tags('query@websitevalley.co.uk') . "\r\n";
            $headers .= "Reply-To: ". strip_tags('query@websitevalley.co.uk') . "\r\n";
            // $headers .= "CC: mjunaiddurrani@hotmail.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            if(mail($to, $subject, $message, $headers)){
              return true;
              
            }else{
                return false;
            }
        }
	}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
