<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Gateway;

class GatewayController extends Controller
{
    public function index()
    {
        $gateway=Gateway::all();
        return $gateway;
    }

    public function store(Request $request)
    {
        return Gateway::create($request->all());
    }

    public function show($id)
    {
        $gateway=Gateway::find($id);

        return $gateway;
    }
    
    public function update(Request $request,$id)
    {
        $gateway=Gateway::find($id);
        $gateway->g_name=$request->g_name;
        $gateway->save();
        
        return response()->json(['message'=>'updated']);
    }
    
    public function destroy($id)
    {
        Gateway::destroy($id);
        return response()->json(['message'=>'deleted']);
    }
    
    public function updateStatus($status,$g_id)
    {
        Gateway::where('g_id' , $g_id)->update([
            'status' => $status
        ]);
            
        return response()->json(['message'=>'status updated']);
    }
}
