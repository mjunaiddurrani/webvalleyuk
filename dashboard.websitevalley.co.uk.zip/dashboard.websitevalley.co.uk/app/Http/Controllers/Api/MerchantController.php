<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Merchant;

class MerchantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $merchants=Merchant::all();
        return $merchants;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(isset($request->allow_refund)){
            $refund = 1;
        }
        elseif(!isset($request->allow_refund)){
            $refund = 0;
        }
        if(isset($request->is_tokenized)){
            $is_tokenized = 1;
        }
        elseif(!isset($request->is_tokenized)){
            $is_tokenized = 0;
        }
        if(isset($request->is_testmode)){
            $is_testmode = 1;
        }
        elseif(!isset($request->is_testmode)){
            $is_testmode = 0;
        }
        if(isset($request->is_handling_allowed)){
            $is_handling_allowed = 1;
        }
        elseif(!isset($request->is_handling_allowed)){
            $is_handling_allowed = 0;
        }
        // dd($refund);
         Merchant::create([
            'title'=>$request->title,
            'mc_id'=>$request->mc_id,
            'g_id'=>$request->g_id,
            'msp_id'=>$request->msp_id,
            'merchant_cor_id'=>$request->merchantcor_id,
            'portal_username'=>$request->portal_username,
            'portal_password'=>$request->portal_password,
            'currency'=>$request->currency,
            'description'=>$request->description,
            'api_username'=>$request->api_username,
            'api_password'=>$request->api_password,
            'api_tanskey'=>$request->api_tanskey,
            'type'=>$request->type,
            'allow_refund'=>$refund,
            'account_number'=>$request->account_number,
            'gateway_version'=>$request->gateway_version,
            'bank_name'=>$request->bank_name,
            'bank_website'=>$request->bank_website,
            'product_name'=>$request->product_name,
            'process_limit'=>$request->process_limit,
            'sales_limit'=>$request->sales_limit,
            'decline_count'=>$request->decline_count,
            'processed_amount'=>$request->processed_amount,
            'reserved_amount'=>$request->reserved_amount,
            'fee_per_transaction'=>$request->fee_per_transaction,
            'merchant_reserved_amount'=>$request->merchant_reserved_amount,
            'discount_fee'=>$request->discount_fee,
            'chargeback_fee'=>$request->chargeback_fee,
            'alert_fee'=>$request->alert_fee,
            'contact_phone'=>$request->contact_phone,
            'contact_email'=>$request->contact_email,
            'support_fix'=>$request->support_fix,
            'trial_days'=>$request->trial_days,
            'gateway_custom1'=>$request->gateway_custom1,
            'gateway_custom2'=>$request->gateway_custom2,
            'is_tokenized'=>$is_tokenized,
            'is_testmode'=>$is_testmode,
            'is_handling_allowed'=>$is_handling_allowed,
            'status_account'=>$request->status_account
        ]);

        return response()->json(['message'=>'created']);
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $merchantdat=Merchant::find($id);
        return $merchantdat;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(isset($request->allow_refund)){
            $refund = 1;
        }
        elseif(!isset($request->allow_refund)){
            $refund = 0;
        }
        if(isset($request->is_tokenized)){
            $is_tokenized = 1;
        }
        elseif(!isset($request->is_tokenized)){
            $is_tokenized = 0;
        }
        if(isset($request->is_testmode)){
            $is_testmode = 1;
        }
        elseif(!isset($request->is_testmode)){
            $is_testmode = 0;
        }
        if(isset($request->is_handling_allowed)){
            $is_handling_allowed = 1;
        }
        elseif(!isset($request->is_handling_allowed)){
            $is_handling_allowed = 0;
        }
        // dd($id);
        $updatemerchant = Merchant::find($id);
            $updatemerchant->title = $request->title;
            $updatemerchant->mc_id = $request->mc_id;
            $updatemerchant->g_id = $request->g_id;
            $updatemerchant->msp_id = $request->msp_id;
            $updatemerchant->merchant_cor_id = $request->merchant_cor_id;
            $updatemerchant->portal_username = $request->portal_username;
            $updatemerchant->portal_password = $request->portal_password;
            $updatemerchant->currency = $request->currency;
            $updatemerchant->description = $request->description;
            $updatemerchant->api_username = $request->api_username;
            $updatemerchant->api_password = $request->api_password;
            $updatemerchant->api_tanskey = $request->api_tanskey;
            $updatemerchant->type = $request->type;
            $updatemerchant->allow_refund = $refund;
            $updatemerchant->account_number = $request->account_number;
            $updatemerchant->gateway_version = $request->gateway_version;
            $updatemerchant->bank_name = $request->bank_name;
            $updatemerchant->bank_website = $request->bank_website;
            $updatemerchant->product_name = $request->product_name;
            $updatemerchant->process_limit = $request->process_limit;
            $updatemerchant->sales_limit = $request->sales_limit;
            $updatemerchant->decline_count = $request->decline_count;
            $updatemerchant->processed_amount = $request->processed_amount;
            $updatemerchant->reserved_amount = $request->reserved_amount;
            $updatemerchant->fee_per_transaction = $request->fee_per_transaction;
            $updatemerchant->merchant_reserved_amount = $request->merchant_reserved_amount;
            $updatemerchant->discount_fee = $request->discount_fee;
            $updatemerchant->chargeback_fee = $request->chargeback_fee;
            $updatemerchant->alert_fee = $request->alert_fee;
            $updatemerchant->contact_phone = $request->contact_phone;
            $updatemerchant->contact_email = $request->contact_email;
            $updatemerchant->support_fix = $request->support_fix;
            $updatemerchant->trial_days = $request->trial_days;
            $updatemerchant->gateway_custom1 = $request->gateway_custom1;
            $updatemerchant->gateway_custom2 = $request->gateway_custom2;
            $updatemerchant->is_tokenized = $is_tokenized;
            $updatemerchant->is_testmode = $is_testmode;
            $updatemerchant->is_handling_allowed = $is_handling_allowed;
            $updatemerchant->status_account = $request->status_account;

            $updatemerchant->save();
        

        return response()->json(['message'=>'updated']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Merchant::destroy($id);
        return response()->json(['message'=>'Deleted']);
    }
}
