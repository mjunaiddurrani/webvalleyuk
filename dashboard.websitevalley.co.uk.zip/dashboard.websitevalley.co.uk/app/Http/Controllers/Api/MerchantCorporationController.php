<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\MerchantCorporation;

class MerchantCorporationController extends Controller
{
    public function index()
    {
        $merchant=MerchantCorporation::all();
        return $merchant;
    }

    public function store(Request $request)
    {
        return MerchantCorporation::create($request->all());
    }

    public function show($id)
    {
        $merchant=MerchantCorporation::find($id);

        return $merchant;
    }
    
    public function update(Request $request,$id)
    {
        $merchant=MerchantCorporation::find($id);
        $merchant->merchantcor_name=$request->merchantcor_name;
        $merchant->save();
        
        return response()->json(['message'=>'updated']);
    }
    
    public function destroy($id)
    {
        MerchantCorporation::destroy($id);
        return response()->json(['message'=>'deleted']);
    }
    
    public function updateStatus($status,$merchantcor_id)
    {
        MerchantCorporation::where('merchantcor_id' , $merchantcor_id)->update([
            'status' => $status
        ]);
            
        return response()->json(['message'=>'status updated']);
    }
}
