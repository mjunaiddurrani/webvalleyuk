<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Role;
use App\Leads;

class RoleController extends Controller
{
   
    public function index()
    {
        $role=Role::all();
        return $role;
    }

    public function store(Request $request)
    {
        return Role::create($request->all());
    }

    public function show($id)
    {
        $role=Role::find($id);

        return $role;
    }
    
    public function update(Request $request,$id)
    {
        $role=Role::find($id);
        $role->role_name=$request->role_name;
        $role->save();
        
        return response()->json(['message'=>'updated']);
    }
    
    public function destroy($id)
    {
        Role::destroy($id);
        return response()->json(['message'=>'deleted']);
    }
    
    public function leads($id){
        $data=Leads::where('token',$id)->first();
        
        return $data;
    }
}
