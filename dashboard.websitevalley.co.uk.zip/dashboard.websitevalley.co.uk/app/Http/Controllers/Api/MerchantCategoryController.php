<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\MerchantCategory;

class MerchantCategoryController extends Controller
{
    public function index()
    {
        $merchant=MerchantCategory::all();
        return $merchant;
    }

    public function store(Request $request)
    {
        return MerchantCategory::create($request->all());
    }

    public function show($id)
    {
        $merchant=MerchantCategory::find($id);

        return $merchant;
    }
    
    public function update(Request $request,$id)
    {
        $merchant=MerchantCategory::find($id);
        $merchant->mc_name=$request->mc_name;
        $merchant->save();
        
        return response()->json(['message'=>'updated']);
    }
    
    public function destroy($id)
    {
        MerchantCategory::destroy($id);
        return response()->json(['message'=>'deleted']);
    }
    
    public function updateStatus($status,$mc_id)
    {
        MerchantCategory::where('mc_id' , $mc_id)->update([
            'status' => $status
        ]);
            
        return response()->json(['message'=>'status updated']);
    }
}
