<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;

class NotificationController extends Controller
{
    public function notificationCheck()
    {
        if(request()->ajax())
        {
            $output="";
            $count=DB::table('error_logs')
            ->join('leads','leads.id','error_logs.user_id')
            ->where('seen_status',0)
            ->where('leads.user_id',Auth::user()->id)
            ->count();
            $notifications_unseen=DB::table('error_logs')
            ->join('leads','leads.id','error_logs.user_id')
            ->where('seen_status',0)
            ->where('leads.user_id',Auth::user()->id)
            ->get();

            foreach ($notifications_unseen as $key => $unseen) 
            {
                $timeago = \illuminate\Support\Carbon::createFromTimeStamp(strtotime($unseen->created_at))->diffForHumans();
                $output.='<div class="dropdown-divider"></div><a href="#" class="dropdown-item" style="background-color: rgb(189 189 189)"><i class="fas fa-envelope mr-2"></i> '.$unseen->fname.' '.$unseen->lname.'<small>('.$unseen->message.')</small> <span class="float-right text-muted text-sm">3 mins</span></a><div class="dropdown-divider"></div>';
            }
            $response=array($count,$output);
            return Response($response);
        }
    }

    public function markRead()
    {
        DB::table('error_logs')
        ->join('leads','leads.id','error_logs.user_id')
        ->where('seen_status',0)
        ->where('leads.user_id',Auth::user()->id)
        ->update([
            'seen_status'=>1
        ]);
        return redirect()->back();
    }
}
