<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\MSP;

class MSPController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $msp = MSP::all();
        return view('msp.index',compact('msp'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('msp.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        MSP::create(['msp_name'=>$request->msp_name]);
        toastr()->success('MSP added successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(request()->ajax()){
            $data = MSP::find($id);
            // dd($data);
            return $data;
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd($request->all());
        MSP::where('msp_id' , $id)->update([
            'msp_name' => $request->msp_name
        ]);
        toastr()->success('Record Updated');
        return response()->json(['message'=>'success']);
    }

    public function updateStatus($status,$msp_id)
    {
        if(request()->ajax())
        {
            MSP::where('msp_id' , $msp_id)->update([
                'status' => $status
            ]);

            return true;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        MSP::destroy($id);
        return $this->index();
    }
}
