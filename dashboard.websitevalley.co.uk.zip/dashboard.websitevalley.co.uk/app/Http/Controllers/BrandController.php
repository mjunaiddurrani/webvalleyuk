<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Brand;
use DB;

class BrandController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Brand = DB::table('brands')
            ->join('stripes','stripes.stripe_id','=','brands.stripe_id')
            ->select('brands.*','stripes.*')->get();
        return view('brands.index',compact('Brand'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Brand::create([
            'stripe_id'=>$request->stripe_id,
            'b_name'=>$request->b_name,
            'b_url'=>$request->b_url
        ]);

        toastr()->success('Brand added Successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Brand  $Brand
     * @return \Illuminate\Http\Response
     */
    public function show(Brand $Brand)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Brand  $Brand
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // dd($id);
        if(request()->ajax())
        {
            // dd(Brand::where('stripe_id',$id)->first());
            $b = DB::table('brands')
            ->join('stripes','stripes.stripe_id','=','brands.stripe_id')
            ->where('brands.b_id','=',$id)->get();
            $data = $b->all();
            return $data;
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Brand  $Brand
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data=Brand::find($id);
        $data->b_name=$request->b_name;
        $data->b_url=$request->b_url;
        $data->stripe_id=$request->stripe_id;
        $data->save();

        toastr()->success("Brand Updated Successfully");
        return response()->json(['message'=>'updated']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Brand  $Brand
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Brand::destroy($id);

        toastr()->error('Brand Deleted Successfully');
        return redirect()->back();
    }
}
