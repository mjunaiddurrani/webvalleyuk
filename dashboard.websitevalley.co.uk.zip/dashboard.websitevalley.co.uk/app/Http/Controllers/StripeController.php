<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Stripe;

class StripeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stripe = Stripe::all();
        return view('stripe.index',compact('stripe'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Stripe::create([
            'title'=>$request->title,
            'publishable_key'=>$request->publishable_key,
            'secret_key'=>$request->secret_key
        ]);

        toastr()->success('Account added Successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(request()->ajax())
        {
            // dd($id);
            $data = Stripe::where('stripe_id', $id)->first();
            return $data;
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd($request,$id);
        Stripe::where('stripe_id' , $id)->update([
            'title' => $request->title,
            'publishable_key' => $request->publishable_key,
            'secret_key' => $request->secret_key,
        ]);

        toastr()->success("Account Updated Successfully");
        return response()->json(['message'=>'updated']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Stripe::where('stripe_id', $id)->delete();

        toastr()->error('Stripe Deleted Successfully');
        return redirect()->back();
    }
}
