<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quote extends Model
{
    protected $table= "quotes";
    protected $primaryKey='id';
    protected $fillable=[
        'name',
        'company',
        'email',
        'phone',
        'subject',
        'amount'
    ];
}
