<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gateway extends Model
{
    protected $table = "gateways";
    protected $primaryKey='g_id';

    protected $fillable = [
        'g_name',
        'status'
    ];

    public function merchant(){
        return $this->hasMany('App\Merchant');
    }
}
