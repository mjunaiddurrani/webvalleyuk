<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    protected $table="currencies";
    protected $priamryKey='id';

    protected $fillable=[
        'curr_type'
    ];
}
