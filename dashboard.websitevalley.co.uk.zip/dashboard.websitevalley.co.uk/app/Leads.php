<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Leads extends Model
{
   protected $table="leads";
   protected $primaryKey='id';
   protected $fillable = [
      'fname',
      'lname',
      'email',
      'address',
      'amount',
      'phonenumber',
      'zipcode',
      'description',
      'url',
      'token',
      'user_id',
      'discount_amount',
      'package_amount',
      'currency',
      'brand'
   ];
   
}
