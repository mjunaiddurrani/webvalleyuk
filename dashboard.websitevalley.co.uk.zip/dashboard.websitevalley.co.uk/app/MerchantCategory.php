<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantCategory extends Model
{
    protected $table = "merchant_categories";
    protected $primaryKey='mc_id';

    protected $fillable = [
        'mc_name',
        'status'
    ];

    public function merchant(){
        return $this->hasMany('App\Merchant');
    }
}
