<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MSP extends Model
{
    protected $table = "m_s_p_s";
    protected $primaryKey='msp_id';

    protected $fillable = [
        'msp_name',
        'status'
    ];

    public function merchant(){
        return $this->hasMany('App\Merchant');
    }
}
