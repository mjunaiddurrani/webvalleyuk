<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantCorporation extends Model
{
    protected $table = "merchant_corporations";
    protected $primaryKey='merchantcor_id';

    protected $fillable = [
        'merchantcor_name',
        'status'
    ];

    public function merchant(){
        return $this->hasMany('App\Merchant');
    }
}
