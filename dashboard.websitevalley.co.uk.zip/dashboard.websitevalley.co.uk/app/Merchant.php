<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Merchant extends Model
{
    protected $table = "merchants";
    protected $primaryKey='merchant_id';

    protected $fillable = [
        'title',
        'mc_id',
        'g_id',
        'msp_id',
        'merchant_cor_id',
        'portal_username',
        'portal_password',
        'currency',
        'description',
        'api_username',
        'api_password',
        'api_tanskey',
        'type',
        'allow_refund',
        'account_number',
        'gateway_version',
        'bank_name',
        'bank_website',
        'product_name',
        'process_limit',
        'sales_limit',
        'decline_count',
        'processed_amount',
        'reserved_amount',
        'fee_per_transaction',
        'merchant_reserved_amount',
        'discount_fee',
        'chargeback_fee',
        'alert_fee',
        'contact_phone',
        'contact_email',
        'support_fix',
        'trial_days',
        'gateway_custom1',
        'gateway_custom2',
        'is_tokenized',
        'is_testmode',
        'is_handling_allowed',
        'status_account'

    ];

    public function categories(){
        return $this->hasOne("App\MerchantCategory",'mc_id','mc_id');
    }
    public function gateway(){
        return $this->hasOne("App\Gateway",'g_id','g_id');
    }
    public function msp(){
        return $this->hasOne("App\MSP",'msp_id','msp_id');
    }
    public function corporation(){
        return $this->hasOne("App\MerchantCorporation",'merchantcor_id','merchant_cor_id');
    }
}
