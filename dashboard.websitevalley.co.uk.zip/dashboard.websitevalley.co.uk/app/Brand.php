<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $table = "brands";
    protected $primaryKey='b_id';

    protected $fillable = [
        'stripe_id',
        'b_name',
        'b_url'
    ];

    public function stripes(){
        return $this->hasOne("App\Stripe",'stripe_id','stripe_id');
    }
}
