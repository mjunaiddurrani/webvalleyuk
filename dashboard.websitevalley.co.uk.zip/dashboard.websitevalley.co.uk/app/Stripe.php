<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stripe extends Model
{
    //
    protected $fillable = ['title' , 'publishable_key' , 'secret_key'];
}
