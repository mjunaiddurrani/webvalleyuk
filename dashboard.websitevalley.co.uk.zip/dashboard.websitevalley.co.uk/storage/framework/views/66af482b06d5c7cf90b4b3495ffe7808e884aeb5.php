<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
            <?php echo e(Auth::user()->name); ?>

        </a>

        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </li>
    <?php
        $count=DB::table('error_logs')
        ->join('leads','leads.id','error_logs.user_id')
        ->where('seen_status',0)
        ->where('leads.user_id',Auth::user()->id)
        ->count();
        $notifications_unseen=DB::table('error_logs')
        ->join('leads','leads.id','error_logs.user_id')
        ->where('seen_status',0)
        ->where('leads.user_id',Auth::user()->id)
        ->get();
        $notifications_seen=DB::table('error_logs')
        ->join('leads','leads.id','error_logs.user_id')
        ->where('seen_status',0)
        ->where('leads.user_id',Auth::user()->id)
        ->limit(3)
        ->get();
    ?>
    <!-- Notifications Dropdown Menu -->
    <li class="nav-item dropdown">
      <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="far fa-bell"></i>
        <span class="badge badge-warning navbar-badge count"><?php echo e($count); ?></span>
      </a>
      <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="min-width: 450px">
        <span class="dropdown-item dropdown-header"><?php echo e($count); ?> Notifications</span>
        <a href="/markRead" class="dropdown-item dropdown-footer">Mark All As Read</a>
        <div id="errors">
          <?php $__currentLoopData = $notifications_unseen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unseen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item" style="background-color: rgb(189 189 189)">
              <i class="fas fa-envelope mr-2"></i> <?php echo e($unseen->fname); ?> <?php echo e($unseen->lname); ?><small>(<?php echo e($unseen->message); ?>)</small> 
              <span class="float-right text-muted text-sm">3 mins</span>
            </a>
            <div class="dropdown-divider"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
      </div>
    </li>
      
    </ul>
  </nav><?php /**PATH /home/logospots/public_html/dashboard/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>