<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
body {
        height: 842px;
        width: 595px;
        /* to centre page on screen*/
        margin-left: auto;
        margin-right: auto;
    }
  /* ... the rest of the rules ... */

</style>
<body>

<div style="width: 800px;margin:0 auto;font-family:airal;">
    <table align='left' width='600'>
        <tr>
            <td>
                <img src='<?php echo e($brand); ?>img/invoice.png' alt='invoice header' width='100%'>
            </td>
        </tr>
    </table>
    <div>
        <?php
            if($currency == "USD"){
                $in_date = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', Carbon\Carbon::now());
                $in_date->setTimezone('America/New_York');
                $symbol = "$";
            }
            elseif($currency == "GBP"){
                $in_date = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', Carbon\Carbon::now());
                $in_date->setTimezone('Europe/London');
                $symbol = "£";
            }
            elseif($currency == "AUD"){
                $in_date = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', Carbon\Carbon::now());
                $in_date->setTimezone('Australia/Sydney');
                $symbol = "A$";
            }
            elseif($currency == "CAD"){
                $in_date = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', Carbon\Carbon::now());
                $in_date->setTimezone('US/Eastern');
                $symbol = "C$";
            }
            elseif($currency == "EUR"){
                $in_date = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', Carbon\Carbon::now());
                $in_date->setTimezone('Europe/Berlin');
                $symbol = "€";
            }
         ?>
        <table align='left'  width='600' style='font-family:arial;font-size: 15px;'> 
            <tr align='left'>
                <td width='33.33333%'>
                    Invoice To: <?php echo e($fname); ?> <?php echo e($lname); ?> <br>
                    Address: <?php echo e($address); ?> <br>
                    Invoice To: <?php echo e($phonenumber); ?>

                </td>
                <td width='33.33333%'></td>
                <td width='33.33333%' align='right'>
                    Invoice No:<?php echo e($id); ?> <br>
                    Invoice Dated:  <?php echo e($in_date); ?>

                </td>
            </tr>
        </table>
        
    </div>
    <br>
    <br>
    <table align='left'  width='600' style='padding: 0;'>
        <tbody style="background-color: #f4f5f6;">
            <tr><td colspan="5" align="left" style="font-size: 25px;font-weight: 800; background:black; color:white;">Invoice Detail</td></tr>
            <tr style='background-color: #fff;' align='left'>
                <th>S.No</th>
                <th>Description</th>
                <th>Amount</th>
            </tr>
            <tr align='left'>
                <td>1</td>
                <td><?php echo e($description); ?></td>
                <td><?php echo e($symbol); ?><?php echo e($amount); ?></td>
            </tr>
            <tr align='left'>
                <td></td>
                <td></td>
                <td>Total: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
            </tr>
            <tr align='left'>
                <td></td>
                <td></td>
                <td>Advance Paid: <?php echo e($symbol); ?> 0</td>
            </tr>
            <tr align='left'>
                <td></td>
                <td></td>
                <?php if($brand=="https://www.ghostwritingfounder.com/"): ?>
                <td width="100px" style="padding: 10px;background: rgb(3, 166, 60);float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.wiki-pros.com/"): ?>
                <td width="100px" style="padding: 10px;background: #0468BE;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.getyourlogo.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #0468BE;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.thewebfounders.com/"): ?>
                <td width="100px" style="padding: 10px;background: #002e66;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.astrosdigital.com/"): ?>
                <td width="100px" style="padding: 10px;background: #f1052f;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.logovalley.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #001787;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.websitevalley.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #000000;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.bookwritingfounders.com/"): ?>
                <td width="100px" style="padding: 10px;background: #3892B0;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.logoshutter.com/"): ?>
                <td width="100px" style="padding: 10px;background: #fcb141;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.logodogo.com/"): ?>
                <td width="100px" style="padding: 10px;background: #307a92;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.thewebfounders.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #002e66;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.theamericanghostwriters.com/"): ?>
                <td width="100px" style="padding: 10px;background: #EC1E4F;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.thewebgroove.com/"): ?>
                <td width="100px" style="padding: 10px;background: #082640;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.bookwritingsolution.com/"): ?>
                <td width="100px" style="padding: 10px;background: #2A3893;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php elseif($brand=="https://www.thewebeez.com/"): ?>
                <td width="100px" style="padding: 10px;background: #56261B;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($amount); ?></td>
                <?php endif; ?>
            </tr>
            <tr>
                <td colspan='5'><img src='<?php echo e($brand); ?>img/footer.png' alt='invoice header' width='100%'></td>
            </tr>
        </tbody>
    </table>

    
</div>
</body>
</html><?php /**PATH /home/logospots/public_html/dashboard/resources/views/email/invoice.blade.php ENDPATH**/ ?>