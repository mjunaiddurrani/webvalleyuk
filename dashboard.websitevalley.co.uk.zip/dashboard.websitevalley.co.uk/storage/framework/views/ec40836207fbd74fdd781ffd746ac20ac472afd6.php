<!DOCTYPE html>
<html>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Brand</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Brand</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Brand List</h3>
                <div class="text-right">
                  <button type="button" class="btn btn-ghost" data-target="#modalinsert-lg" data-toggle="modal"><i class="fa fa-plus"></i></button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>ID</th>
                    <th>Brand Name</th>
                    <th>Brand URL</th>
                    <th>Assigned Account</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $Brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($brand->b_id); ?></td>
                        <td><?php echo e($brand->b_name); ?></td>
                        <td><?php echo e($brand->b_url); ?></td>
                        <td><?php echo e($brand->title); ?></td>
                        <td>
                          <button type="button" id="<?php echo e($brand->b_id); ?>" class="btn btn-warning id mb-2" data-toggle="modal" data-target="#modal-lg">
                            <i class="fa fa-edit"></i>
                          </button>
                          <form action="brand/<?php echo e($brand->b_id); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">
                              <i class="fa fa-trash"></i>
                            </button>
                          </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          
                </tbody>
                  <tfoot>
                  <tr>
                    <th>ID</th>
                    <th>Brand Name</th>
                    <th>Brand URL</th>
                    <th>Assigned Account</th>
                    <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <div class="modal fade" id="modal-lg" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Edit</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <form id="form">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="brand_name">Brand Name</label>
                  <input type="text" class="form-control" id="b_name" name="b_name" placeholder="Enter Brand Name">
                  <input type="hidden" id="b_id" name="b_id">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="brand_name">Brand Url</label>
                  <input type="text" class="form-control" id="b_url" name="b_url" placeholder="Enter Brand URL">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <select type="text" class="form-control" id="stripe_id" name="stripe_id" placeholder="Select Account">
                  <option></option>
                  <?php
                   $account = App\Stripe::all();   
                  ?>
                  <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($accounts->stripe_id); ?>"><?php echo e($accounts->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
        </div>
        <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary updatebtn">Update</button>
        </div>
          </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
  <div class="modal fade" id="modalinsert-lg" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Add New Brand</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('brand.store')); ?>" method="POST" id="form-validate">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="curr_type">Brand Name</label>
                            <input type="text" class="form-control" name="b_name" placeholder="Enter Brand Name">
                          </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="curr_type">Brand URL</label>
                            <input type="text" class="form-control" name="b_url" placeholder="Enter URL">
                          </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="curr_type">Assign Account</label>
                            <select type="text" class="form-control" id="stripe_id" name="stripe_id" placeholder="Select Account">
                              <?php
                               $account = App\Stripe::all();   
                              ?>
                              <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($accounts->stripe_id); ?>"><?php echo e($accounts->title); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                    </div>
                </div>
              </div>
              <div class="card-footer">
              <button type="submit" class="btn btn-primary mr-2">Submit</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              </div>
            </form>
          
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(URL::asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable({});
  });

  $(document).on('click' , '.id' , function(){
    var id = $(this).attr('id');
    $.ajax({
      url: '/brand/'+id+'/edit',
      method: 'GET',
      dataType: 'json',
      success:function(data){
        // alert(data[0].title)
        $('#b_name').val(data[0].b_name); 
        $('#b_url').val(data[0].b_url); 
        $('#b_id').val(data[0].b_id);
        // $('#stripe_id').empty()
        var div_data="<option value="+data[0].stripe_id+" selected>"+data[0].title+"</option>";
        $(div_data).appendTo('#stripe_id'); 
      },
      error:function(e){
        console.log(e);
      }
    });
  });

  $(document).on('click','.updatebtn' , function(){
    var b_name = $('#b_name').val();
    var b_url = $('#b_url').val();
    var stripe_id = $('#stripe_id').val();
    var b_id = $('#b_id').val();
    // $('#status').val();
    // console.log(curr_type,id);
    $.ajax({
      url: 'brand/'+b_id,
      method: 'PUT',
      dataType: 'json',
      data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                // "status" : status,
                "b_name" : b_name,
                "b_url" : b_url,
                "stripe_id" : stripe_id,
            },
      success:function(){
        location.reload(true);
      },
      error:function(e){
        console.log(e);
      }
    });
  });

</script>
</body>
</html>
<?php /**PATH /home/logospots/public_html/dashboard/resources/views/brands/index.blade.php ENDPATH**/ ?>