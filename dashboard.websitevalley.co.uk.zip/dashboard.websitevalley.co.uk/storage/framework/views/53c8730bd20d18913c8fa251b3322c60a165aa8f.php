<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
      <img src="<?php echo e(URL::asset('logo_ghost.png')); ?>" alt="Ghost Writing" class="brand-image img-square">
      <span class="brand-text font-weight-light">Dashboard</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(URL::asset('dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo e(auth()->user()->name); ?></a>
        </div>
      </div>
      <?php
          $admin=App\Role::where('role_name','like','%Admin%')->first();
          $sales=App\Role::where('role_name','like','%Sale%')->first();
          $segment1=Request::segment(1);
          $segment2=Request::segment(2);
      ?>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Admin SideBar -->
               <?php if(Auth::user()->roleId == $admin->role_id): ?>
                <li class="nav-item has-treeview <?php echo e($segment1=="roles" ? 'menu-open' : null); ?>">
                <a href="#" class="nav-link <?php echo e($segment1=="roles" ? 'active' : null); ?>">
                  <i class="nav-icon fas fa-user-tag"></i>
                  <p>
                    Roles Management
                    <i class="fas fa-angle-left right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview" style="display: <?php echo e($segment1=="roles" ? 'block' : 'none'); ?>;">
                  <li class="nav-item">
                    <a href="<?php echo e(route('roles.create')); ?>" class="nav-link <?php echo e($segment1=="roles" && $segment2=="create" ? 'active' : null); ?>">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Add New Role</p>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo e(route('roles.index')); ?>" class="nav-link <?php echo e($segment1=="roles" && $segment2==null ? 'active' : null); ?>">
                      <i class="far fa-circle nav-icon"></i>
                      <p>View Roles</p>
                    </a>
                  </li>
                </ul>
              </li>
                <li class="nav-item has-treeview <?php echo e($segment1=="currency" ? 'menu-open' : null); ?>">
                <a href="#" class="nav-link <?php echo e($segment1=="currency" ? 'active' : null); ?>">
                  <i class="nav-icon fas fa-dollar-sign"></i>
                  <p>
                    Currency Management
                    <i class="fas fa-angle-left right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview" style="display: <?php echo e($segment1=="currency" ? 'block' : 'none'); ?>;">
                  <li class="nav-item">
                    <a href="<?php echo e(route('currency.index')); ?>" class="nav-link <?php echo e($segment1=="currency" ? 'active' : null); ?>">
                      <i class="far fa-circle nav-icon"></i>
                      <p>View Currencies</p>
                    </a>
                  </li>
                </ul>
              </li>
                <li class="nav-item has-treeview <?php echo e($segment1=="stripe" ? 'menu-open' : null); ?>">
                <a href="#" class="nav-link <?php echo e($segment1=="stripe" ? 'active' : null); ?>">
                  <i class="nav-icon fab fa-stripe"></i>
                  <p>
                    Stripe Management
                    <i class="fas fa-angle-left right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview" style="display: <?php echo e($segment1=="stripe" ? 'block' : 'none'); ?>;">
                  <li class="nav-item">
                    <a href="<?php echo e(route('stripe.index')); ?>" class="nav-link <?php echo e($segment1=="stripe" ? 'active' : null); ?>">
                      <i class="far fa-circle nav-icon"></i>
                      <p>View Stripe Account</p>
                    </a>
                  </li>
                </ul>
              </li>
                <li class="nav-item has-treeview <?php echo e($segment1=="brand" ? 'menu-open' : null); ?>">
                <a href="#" class="nav-link <?php echo e($segment1=="brand" ? 'active' : null); ?>">
                  <i class="nav-icon far fa-copyright"></i>
                  <p>
                    Brand Management
                    <i class="fas fa-angle-left right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview" style="display: <?php echo e($segment1=="brand" ? 'block' : 'none'); ?>;">
                  <li class="nav-item">
                    <a href="<?php echo e(route('brand.index')); ?>" class="nav-link <?php echo e($segment1=="brand" ? 'active' : null); ?>">
                      <i class="far fa-circle nav-icon"></i>
                      <p>View Brands</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="nav-item has-treeview <?php echo e($segment1==="quote" || $segment1==="quote" ? 'menu-open' : null); ?>">
                  <a href="#" class="nav-link <?php echo e($segment1==="quote" || $segment1==="quote" ? 'active' : null); ?>">
                    <i class="fas fa-quote-left"></i>
                    <p>
                      Quote Management
                      <i class="fas fa-angle-left right"></i>
                    </p>
                  </a>
                  <ul class="nav nav-treeview" style="display: <?php echo e($segment1==="quote" || $segment1==="quote" ? 'block' : 'none'); ?>;">
                    <li class="nav-item">
                      <a href="<?php echo e(route('quote.index')); ?>" class="nav-link <?php echo e($segment1==="quote" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>View Quote Leads</p>
                      </a>
                    </li>
                  </ul>
                </li>
              <li class="nav-item has-treeview <?php echo e($segment1==="customers" || $segment1==="customer" ? 'menu-open' : null); ?>">
                  <a href="#" class="nav-link <?php echo e($segment1==="customers" || $segment1==="customer" ? 'active' : null); ?>">
                    <i class="nav-icon fas fa-chalkboard"></i>
                    <p>
                      Leads Management
                      <i class="fas fa-angle-left right"></i>
                    </p>
                  </a>
                  <ul class="nav nav-treeview" style="display: <?php echo e($segment1==="customers" || $segment1==="customer" ? 'block' : 'none'); ?>;">
                    <li class="nav-item">
                      <a href="<?php echo e(route('customer.create')); ?>" class="nav-link <?php echo e($segment1==="customer" && $segment2==="create" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Add New Leads</p>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('customers')); ?>" class="nav-link <?php echo e($segment1==="customers" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>View Leads</p>
                      </a>
                    </li>
                  </ul>
                </li>
              <li class="nav-item has-treeview <?php echo e($segment1==="merchantCategory" || $segment1==="gateway" || $segment1==="msp" || $segment1==="merchantCorporation"  ? 'menu-open' : null); ?>">
                  <a href="#" class="nav-link <?php echo e($segment1==="merchantCategory" || $segment1==="gateway" || $segment1==="msp" || $segment1==="merchantCorporation"  ? 'active' : null); ?>">
                    <i class="nav-icon fas fa-align-justify"></i>
                    <p>
                      Mid Management
                      <i class="fas fa-angle-left right"></i>
                    </p>
                  </a>
                  <ul class="nav nav-treeview" style="display: <?php echo e($segment1==="merchantCategory" || $segment1==="gateway" || $segment1==="msp" || $segment1==="merchantCorporation"  ? 'block' : 'none'); ?>;">
                    <li class="nav-item">
                      <a href="<?php echo e(route('merchantCategory.index')); ?>" class="nav-link <?php echo e($segment1==="merchantCategory" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Categories</p>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('gateway.index')); ?>" class="nav-link <?php echo e($segment1==="gateway" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Gateways</p>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('msp.index')); ?>" class="nav-link <?php echo e($segment1==="msp" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>MSP</p>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('merchantCorporation.index')); ?>" class="nav-link <?php echo e($segment1==="merchantCorporation" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Merchant Corporation</p>
                      </a>
                    </li>
                  </ul>
  
                </li>
                <li class="nav-item has-treeview <?php echo e($segment1=="merchant" ? 'menu-open' : null); ?>">
                  <a href="#" class="nav-link <?php echo e($segment1=="merchant" ? 'active' : null); ?>">
                    <i class="nav-icon fas fa-drafting-compass"></i>
                    <p>
                      Merchants
                      <i class="fas fa-angle-left right"></i>
                    </p>
                  </a>
                  <ul class="nav nav-treeview" style="display: <?php echo e($segment1=="merchant" ? 'block' : 'none'); ?>;">
                    <li class="nav-item">
                      <a href="<?php echo e(route('merchant.create')); ?>" class="nav-link <?php echo e($segment1=="merchant" && $segment2=="create" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Add New Merchant</p>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('merchant.index')); ?>" class="nav-link <?php echo e($segment1=="merchant" && $segment2==null  ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>View Merchants</p>
                      </a>
                    </li>
                  </ul>
                </li>
              <li class="nav-item has-treeview <?php echo e($segment1=="leads" ? 'menu-open' : null); ?>">
                  <a href="#" class="nav-link <?php echo e($segment1=="leads" ? 'active' : null); ?>">
                    <i class="nav-icon fas fa-file-invoice"></i>
                    <p>
                      Invoice Management
                      <i class="fas fa-angle-left right"></i>
                    </p>
                  </a>
                  <ul class="nav nav-treeview" style="display: <?php echo e($segment1=="leads" ? 'block' : 'none'); ?>;">
                    <li class="nav-item">
                      <a href="<?php echo e(route('leads.create')); ?>" class="nav-link <?php echo e($segment1=="leads" && $segment2=="create" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Add New Invoice</p>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('leads.index')); ?>" class="nav-link <?php echo e($segment1=="leads" && $segment2==null ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>View Invoices</p>
                      </a>
                    </li>
                  </ul>
                </li>
              <li class="nav-item has-treeview <?php echo e($segment1=="users" ? 'menu-open' : null); ?>">
                  <a href="#" class="nav-link <?php echo e($segment1=="users" ? 'active' : null); ?>">
                    <i class="nav-icon fas fa-user"></i>
                    <p>
                      User Management
                      <i class="fas fa-angle-left right"></i>
                    </p>
                  </a>
                  <ul class="nav nav-treeview" style="display:  <?php echo e($segment1=="users" ? 'block' : 'none'); ?>;">
                    <li class="nav-item">
                      <a href="<?php echo e(route('users.create')); ?>" class="nav-link <?php echo e($segment1=="users" && $segment2=="create" ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Add New User</p>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e($segment1=="users" && $segment2==null ? 'active' : null); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>View User</p>
                      </a>
                    </li>
                  </ul>
                </li>
            <li class="nav-item <?php echo e($segment1=="subscription" ? 'active' : null); ?>">
              <a href="<?php echo e(route('subscription')); ?>" class="nav-link <?php echo e($segment1=="subscription" ? 'active' : null); ?>">
                <i class="nav-icon fa fa-user-plus"></i>
                <p>
                  Customer Subscription
                </p>
              </a>
            </li>
            <li class="nav-item <?php echo e($segment1=="payments" ? 'active' : null); ?>">
              <a href="<?php echo e(route('payments')); ?>" class="nav-link <?php echo e($segment1=="payments" ? 'active' : null); ?>">
                <i class="nav-icon fas fa-money-check-alt"></i>
                <p>
                  Payments
                </p>
              </a>
            </li>
               <?php endif; ?>


            <!-- Sales SideBar -->
            <?php if(Auth::user()->roleId == $sales->role_id): ?>
            <li class="nav-item has-treeview">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-chalkboard"></i>
                <p>
                  Leads Management
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview" style="display: none;">
                <li class="nav-item">
                  <a href="<?php echo e(route('customer.create')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Add New Leads</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('customers')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>View Leads</p>
                  </a>
                </li>
              </ul>
            </li>
            <li class="nav-item has-treeview">
              <a href="#" class="nav-link">
                <i class="nav-icon fas fa-file-invoice"></i>
                <p>
                  Invoice Management
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview" style="display: none;">
                <li class="nav-item">
                  <a href="<?php echo e(route('leads.create')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Add New Invoice</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('leads.index')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>View Invoices</p>
                  </a>
                </li>
              </ul>
            </li>
            <?php endif; ?>

          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH /home/logospots/public_html/dashboard/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>