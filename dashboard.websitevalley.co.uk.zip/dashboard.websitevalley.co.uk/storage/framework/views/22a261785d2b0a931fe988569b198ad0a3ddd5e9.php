<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
body {
        height: 842px;
        width: 595px;
        /* to centre page on screen*/
        margin-left: auto;
        margin-right: auto;
    }
  /* ... the rest of the rules ... */

</style>
<body>



<div style="width: 800px;margin:0 auto;font-family:airal;">
    <table align='left' width='600'>
        <tr>
            <td>
                <img src='<?php echo e($data["brand"]); ?>img/invoice.png' alt='invoice header' width='100%'>
            </td>
        </tr>
    </table>
    <div>
        <?php

            $in_date = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', Carbon\Carbon::now());
            if($data['currency'] == "USD"){
                $in_date->setTimezone('America/New_York');
                $symbol = "$";
            }
            elseif($data['currency'] == "GBP"){
                
                $in_date->setTimezone('Europe/London');
                $symbol = "£";
            }
            elseif($data['currency'] == "AUD"){
                
                $in_date->setTimezone('Australia/Sydney');
                $symbol = "A$";
            }
            elseif($data['currency'] == "CAD"){
                
                $in_date->setTimezone('US/Eastern');
                $symbol = "C$";
            }
            elseif($data['currency'] == "EUR"){
                
                $in_date->setTimezone('Europe/Berlin');
                $symbol = "€";
            }
         ?>
        <table align='left'  width='600' style='font-family:arial;font-size: 15px;'> 
            <tr align='left'>
                <td width='33.33333%'>
                    Invoice To: <?php echo e($data['fname']); ?> <?php echo e($data['lname']); ?> <br>
                    Address: <?php echo e($data['address']); ?> <br>
                    Invoice To: <?php echo e($data['phonenumber']); ?>

                </td>
                <td width='33.33333%'></td>
                <td width='33.33333%' align='right'>
                    Invoice No:<?php echo e($data['id']); ?> <br>
                    Invoice Dated:  <?php echo e($in_date); ?>

                </td>
            </tr>
        </table>
        
    </div>
    <br>
    <br>
    <table align='left'  width='600' style='padding: 0;'>
        <tbody style="background-color: #f4f5f6;">
            <tr><td colspan="5" align="left" style="font-size: 25px;font-weight: 800; background:black; color:white;">Invoice Detail</td></tr>
            <tr style='background-color: #fff;' align='left'>
                <th>S.No</th>
                <th>Description</th>
                <th>Amount</th>
            </tr>
            <tr align='left'>
                <td>1</td>
                <td><?php echo e($data['description']); ?></td>
                <td><?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
            </tr>
            <tr align='left'>
                <td></td>
                <td></td>
                <td>Total: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
            </tr>
            <tr align='left'>
                <td></td>
                <td></td>
                <td>Advance Paid: <?php echo e($symbol); ?> 0</td>
            </tr>
            <tr align='left'>
                <td></td>
                <td></td>
                <?php if($data['brand']=="https://www.ghostwritingfounder.com/"): ?>
                <td width="100px" style="padding: 10px;background: rgb(3, 166, 60);float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.wiki-pros.com/"): ?>
                <td width="100px" style="padding: 10px;background: #0468BE;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.getyourlogo.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #0468BE;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.thewebfounders.com/"): ?>
                <td width="100px" style="padding: 10px;background: #002e66;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.astrosdigital.com/"): ?>
                <td width="100px" style="padding: 10px;background: #f1052f;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.logovalley.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #001787;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.websitevalley.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #000000;float: right;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.bookwritingfounders.com/"): ?>
                <td width="100px" style="padding: 10px;background: #3892B0;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.logoshutter.com/"): ?>
                <td width="100px" style="padding: 10px;background: #fcb141;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.logodogo.com/"): ?>
                <td width="100px" style="padding: 10px;background: #307a92;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.thewebfounders.co.uk/"): ?>
                <td width="100px" style="padding: 10px;background: #002e66;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.theamericanghostwriters.com/"): ?>
                <td width="100px" style="padding: 10px;background: #EC1E4F;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.thewebgroove.com/"): ?>
                <td width="100px" style="padding: 10px;background: #082640;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.bookwritingsolution.com/"): ?>
                <td width="100px" style="padding: 10px;background: #2A3893;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php elseif($data['brand']=="https://www.thewebeez.com/"): ?>
                <td width="100px" style="padding: 10px;background: #56261B;float: right;width: 100px;color:#fff">Unpaid Amount: <?php echo e($symbol); ?><?php echo e($data['amount']); ?></td>
                <?php endif; ?>
            </tr>
            <tr>
                <td colspan='5'><img src='<?php echo e($data['brand']); ?>img/footer.png' alt='invoice header' width='100%'></td>
            </tr>
        </tbody>
    </table>

    
</div>
</body>
</html><?php /**PATH /home/websitevalleyco/public_html/dashboard.websitevalley.co.uk/resources/views/email/invoice.blade.php ENDPATH**/ ?>