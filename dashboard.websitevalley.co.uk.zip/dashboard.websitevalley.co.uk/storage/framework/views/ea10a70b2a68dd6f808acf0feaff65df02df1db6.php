<!DOCTYPE html>
<html>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">

<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Invoices</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Invoices</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Invoice List</h3>
                <div class="text-right">
                  <a href="<?php echo e(route('leads.create')); ?>"><button type="button" class="btn btn-ghost"><i class="fa fa-plus"></i></button></a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped table-responsive">
                  <thead>
                  <tr>
                    <th>Serial No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Amount</th>
                    <th>Url</th>
                    <th>Brand</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($lead->id); ?></td>
                        <td><?php echo e($lead->fname); ?> <?php echo e($lead->lname); ?></td>
                        <td><?php echo e($lead->email); ?></td>
                        <td><?php echo e($lead->phonenumber); ?></td>
                        <td><?php echo e($lead->address); ?></td>
                        <td><?php echo e($lead->amount); ?></td>
                        <td>
                          <?php if($lead->url!=null): ?>
                          <div class="input-group mb-3 ">
                            <input type="text" id="<?php echo e($lead->id); ?>" value="<?php echo e($lead->url); ?>" class="form-control">
                            <div class="input-group-append">
                              <button class="input-group-text copyLink" data-id="<?php echo e($lead->id); ?>"><i class="fas fa-copy mr-2"></i> Copy Link</button>
                            </div>
                          </div>
                          
                          <?php else: ?>
                            <pre>No link Found</pre>                              
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($lead->brand); ?></td>
                        <td>
                          <form action="leads/<?php echo e($lead->id); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">
                              <i class="fa fa-trash"></i>
                            </button>
                          </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          
                </tbody>
                  <tfoot>
                  <tr>
                    <th>Transaction ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Amount</th>
                    <th>url</th>
                    <th>Brand</th>
                    <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(URL::asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable({
        "ordering": false,
      
    });
  });
  $(document).on('click','.copyLink',function(){
  var copyText = $(this).attr('data-id');
  var text = document.getElementById(copyText);
  // alert(text);
  text.select();
  text.setSelectionRange(0, 99999)
  document.execCommand("copy");
  Swal.fire({
    position: 'top-end',
    icon: 'success',
    title: 'Successfully Copied',
    showConfirmButton: false,
    timer: 700
    })

  })
</script>
</body>
</html>
<?php /**PATH F:\wamp64\www\dashboardnew\resources\views/leads/index.blade.php ENDPATH**/ ?>