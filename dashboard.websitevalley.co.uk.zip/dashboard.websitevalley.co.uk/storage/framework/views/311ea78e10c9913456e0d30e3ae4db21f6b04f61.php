<!DOCTYPE html>
<html>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Brand</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Brand</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Accounts List</h3>
                <div class="text-right">
                  <button type="button" class="btn btn-ghost" data-target="#modalinsert-lg" data-toggle="modal"><i class="fa fa-plus"></i></button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Publishable Key</th>
                    <th>Secret Key</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $stripe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stripes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($stripes->stripe_id); ?></td>
                        <td><?php echo e($stripes->title); ?></td>
                        <td><?php echo e($stripes->publishable_key); ?></td>
                        <td><?php echo e($stripes->secret_key); ?></td>
                        <td>
                          <button type="button" id="<?php echo e($stripes->stripe_id); ?>" class="btn btn-warning mb-2 stripe_id" data-toggle="modal" data-target="#modal-lg">
                            <i class="fa fa-edit"></i>
                          </button>
                          <form action="stripe/<?php echo e($stripes->stripe_id); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">
                              <i class="fa fa-trash"></i>
                            </button>
                          </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          
                </tbody>
                  <tfoot>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Publishable Key</th>
                    <th>Secret Key</th>
                    <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <div class="modal fade" id="modal-lg" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Edit</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <form id="form">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="Title">Title</label>
                  <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title">
                  <input type="hidden" id="stripe_id" name="stripe_id">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="publishable_key">Publishable Key</label>
                  <input type="text" class="form-control" id="publishable_key" name="publishable_key" placeholder="Enter Brand URL">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="secret_key">Secret Key</label>
                  <input type="text" class="form-control" id="secret_key" name="secret_key" placeholder="Enter Secret Key">
                </div>
            </div>
            </div>
        </div>
        <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary updatebtn">Update</button>
        </div>
          </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
  <div class="modal fade" id="modalinsert-lg" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Add New Account</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('stripe.store')); ?>" method="POST" id="form-validate">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="curr_type">Title</label>
                            <input type="text" class="form-control" name="title" placeholder="Enter Title">
                          </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="curr_type">Publishable Key</label>
                            <input type="text" class="form-control" name="publishable_key" placeholder="Enter Publishable Key">
                          </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="curr_type">Secret Key</label>
                            <input type="text" class="form-control" name="secret_key" placeholder="Secret Key">
                          </div>
                    </div>
                </div>
              </div>
              <div class="card-footer">
              <button type="submit" class="btn btn-primary mr-2">Submit</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              </div>
            </form>
          
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(URL::asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable({});
  });

  $(document).on('click' , '.stripe_id' , function(){
    var id = $(this).attr('id');
    // console.log(id);
    $.ajax({
      url: '/stripe/'+id+'/edit',
      method: 'GET',
      dataType: 'json',
      success:function(data){
        $('#title').val(data.title); 
        $('#publishable_key').val(data.publishable_key); 
        $('#secret_key').val(data.secret_key);
        $('#stripe_id').val(data.stripe_id); 
      },
      error:function(e){
        console.log(e);
      }
    });
  });

  $(document).on('click','.updatebtn' , function(){
    var title = $('#title').val();
    var publishable_key = $('#publishable_key').val();
    var secret_key = $('#secret_key').val();
    var stripe_id = $('#stripe_id').val();
    // $('#status').val();
    // console.log(curr_type,id);
    $.ajax({
      url: 'stripe/'+stripe_id,
      method: 'PUT',
      dataType: 'json',
      data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                // "status" : status,
                "title" : title,
                "publishable_key" : publishable_key,
                "secret_key" : secret_key,
            },
      success:function(){
        location.reload(true);
      },
      error:function(e){
        console.log(e);
      }
    });
  });

</script>
</body>
</html>
<?php /**PATH /home/logospots/public_html/dashboard/resources/views/stripe/index.blade.php ENDPATH**/ ?>