<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<h1>Request to start</h1>
<table width='100%' border='1'> 
        <tbody>
        <tr><td colspan='5' align='center' style='font-size: 25px;font-weight: 800;'>User Details</td></tr>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>brief</th>
            <th>News subscription</th>
        </tr>
        <tr>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->email); ?></td>
            <td><?php echo e($data->phone); ?></td>
            <td><?php echo e($data->brief); ?></td>
            <td><?php echo e($data->news); ?></td>
        </tr>
        </tbody>
        </table>


</body>
</html><?php /**PATH /home/websitevalleyco/public_html/dashboard.websitevalley.co.uk/resources/views/email/query.blade.php ENDPATH**/ ?>