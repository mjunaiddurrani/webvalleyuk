<!DOCTYPE html>
<html>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Merchant Category</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Merchant Category</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Merchant Category List</h3>
                <div class="text-right">
                  <a href="<?php echo e(route('merchant.create')); ?>"><button type="button" class="btn btn-ghost"><i class="fa fa-plus"></i></button></a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Merchant Category</th>
                    <th>Merchant Gateway</th>
                    <th>Merchant MSP</th>
                    <th>Merchant Corporation</th>
                    <th>Portal Username</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($merchant->merchant_id); ?></td>
                        <td><?php echo e($merchant->title); ?></td>
                        <td><?php echo e($merchant->categories->mc_name); ?></td>
                        <td><?php echo e($merchant->gateway->g_name); ?></td>
                        <td><?php echo e($merchant->msp->msp_name); ?></td>
                        <td><?php echo e($merchant->corporation->merchantcor_name); ?></td>
                        <td><?php echo e($merchant->portal_username); ?></td>
                        <td>
                          <a href="merchant/<?php echo e($merchant->merchant_id); ?>">
                            <button type="button" class="btn btn-info mb-2">
                              <i class="fa fa-eye"></i>
                            </button>
                          </a>
                        <form action="merchant/<?php echo e($merchant->merchant_id); ?>/edit" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('GET'); ?>
                            <button type="submit" class="btn btn-warning mb-2 merchant-id" data-toggle="modal" data-target="#modal-lg">
                            <i class="fa fa-edit"></i>
                          </button>
                        </form>
                          <form action="/merchant/<?php echo e($merchant->merchant_id); ?>" method="POST" accept-charset="utf-8">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">
                              <i class="fa fa-trash"></i>
                            </button>
                          </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          
                </tbody>
                  <tfoot>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Merchant Category</th>
                    <th>Merchant Gateway</th>
                    <th>Merchant MSP</th>
                    <th>Merchant Corporation</th>
                    <th>Portal Username</th>
                    <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(URL::asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable({});
  });

  $(document).on('click' , '.merchant-id' , function(){
    var cat_id = $(this).attr('id');
    $.ajax({
      url: '/merchant/'+cat_id+'/edit',
      method: 'GET',
      dataType: 'json',
      success:function(data){
        $('#mc_name').val(data.mc_name); 
        $('#mc_id').val(data.mc_id); 
        if(data.status == 1){
          $('#status').prop('checked',true);
        }
        console.log(data);
      },
      error:function(e){
        console.log(e);
      }
    });
  });

  $(document).on('click','.updatebtn' , function(){
    var mc_name = $('#mc_name').val();
    var mc_id = $('#mc_id').val();
    // $('#status').val();
    console.log(mc_name,mc_id,status);
    $.ajax({
      url: 'merchant/'+mc_id,
      method: 'PUT',
      dataType: 'json',
      data: {
                "_token": "<?php echo e(csrf_token()); ?>",
                // "status" : status,
                "mc_name" : mc_name,
            },
      success:function(){
        location.reload(true);
      },
      error:function(e){
        console.log(e);
      }
    });
  });
</script>
</body>
</html>
<?php /**PATH /home/logospots/public_html/dashboard/resources/views/merchants/index.blade.php ENDPATH**/ ?>