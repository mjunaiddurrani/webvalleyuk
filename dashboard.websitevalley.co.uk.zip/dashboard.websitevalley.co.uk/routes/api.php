<?php

// use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/register', 'Api\AuthController@register');
Route::post('/login', 'Api\AuthController@login');

// Route::group(['middleware' => ['cors']], function () {
    // Customer
    Route::get('/subscription', 'Api\CustomerController@subscription')->name('subscription');
    Route::get('/payments', 'Api\CustomerController@payments')->name('payments');
    Route::resource('/customer','Api\CustomerController');
    Route::get('/customers', 'Api\CustomerController@customers')->name('customers');
    
    // Gateway api
    Route::resource('/gateway','Api\GatewayController');
    Route::get('/updateStatusGateway/{status}/g_id/{g_id}','Api\GatewayController@updateStatus');
    // MSP api
    Route::resource('/msp','Api\MSPController');
    Route::get('/updateStatusMsp/{status}/msp_id/{msp_id}','Api\MSPController@updateStatus');
    // Merchant Category api
    Route::resource('/merchantCategory','Api\MerchantCategoryController');
    Route::get('/updateStatusMerchantCategory/{status}/mc_id/{mc_id}','Api\MerchantCategoryController@updateStatus');
    // Merchant Corporation api
    Route::resource('/merchantCorporation','Api\MerchantCorporationController');
    Route::get('/updateStatusMerchantCorporation/{status}/merchantcor_id/{merchantcor_id}','Api\MerchantCorporationController@updateStatus');
    // Role api
    Route::resource('/roles','Api\RoleController');
    //Merchant
    Route::resource('/merchant','Api\MerchantController');
    //Currency
    Route::resource('/currency','Api\CurrencyController');
    Route::resource('/quote','Api\QuoteController');

    Route::get('/leads/{id}','Api\RoleController@leads');

    Route::post('/error_log','Api\ErrorLogController@store');
// });
