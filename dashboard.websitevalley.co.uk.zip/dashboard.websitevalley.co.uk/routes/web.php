<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();
Route::post('logout',function(){
    Auth::logout();
    return redirect('/login');
})->name('logout');
    
Route::group(['middleware'=>['auth:web','role:admin']],function () {
    Route::get('/subscription', 'CustomerController@subscription')->name('subscription');
    Route::get('/payments', 'CustomerController@payments')->name('payments');
    Route::resource('/users','UserController');
    Route::resource('/roles','RoleController');
    Route::resource('/merchantCategory','MerchantCategoryController');
    Route::get('/updateStatusMerchantCategory/{status}/mc_id/{mc_id}','MerchantCategoryController@updateStatus');
    Route::resource('/merchantCorporation','MerchantCorporationController');
    Route::get('/updateStatusMerchantCorporation/{status}/merchantcor_id/{merchantcor_id}','MerchantCorporationController@updateStatus');
    Route::resource('/gateway','GatewayController');
    Route::get('/updateStatusGateway/{status}/g_id/{g_id}','GatewayController@updateStatus');
    Route::resource('/msp','MSPController');
    Route::get('/updateStatusMsp/{status}/msp_id/{msp_id}','MspController@updateStatus');
    Route::resource('/merchant','MerchantController');
    Route::resource('/currency','CurrencyController');
    Route::resource('/brand','BrandController');
    Route::resource('/stripe','StripeController');
    Route::resource('/quote','QuoteController');
});

Route::group(['middleware'=>['auth','role:admin.sales']],function(){
    Route::get('/', 'HomeController@index')->name('home');
    Route::resource('/leads','LeadController');
    Route::any('/unpaidinvoice/{id}','LeadController@unpaidinvoice');   
    Route::resource('/customer','CustomerController');
    Route::get('/customers', 'CustomerController@customers')->name('customers');

    Route::get('/notificationCheck','NotificationController@notificationCheck');
    Route::get('/markRead','NotificationController@markRead');
    Route::get('/mail','TestEmail@index');

});
